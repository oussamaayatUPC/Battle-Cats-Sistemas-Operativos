Proyecto del grupo 02 de Sistemas Operativos (2022-23-Q1)
Battle Cats SO
Versión 1 generada por Oussama Ayat
Versión 1 verificada por Biel Arnal
<<<<<<< HEAD
Versión 1 comunicada por Aleix Balust
URL: https://youtu.be/3wKaBThd_qE
Versión 2 generado por Biel Arnal
Versión 2 verificada por Aleix Balust 
Version 2 comunicada por Oussama Ayat 
URL Sprites: https://drive.google.com/file/d/1uEmB-Hit6mvGJUvQFNvMyFMWq4H91Szo/view?usp=sharing 
URL Código https://drive.google.com/file/d/1Jb3OOiYxJN0XmIgYFJtl7-YPYsYUEhv3/view?usp=sharing
=======
Version 1 comunicada por Aleix Balust
URL: https://youtu.be/3wKaBThd_qE
Versión 2 generada por Biel Arnal
Versión 2 verificada por Aleix Balust
Version 2 comunicada por Oussama Ayat
URL Sprites: 
https://drive.google.com/file/d/1uEmB-Hit6mvGJUvQFNvMyFMWq4H91Szo/view?usp=sharing
URL Código
https://drive.google.com/file/d/1Jb3OOiYxJN0XmIgYFJtl7-YPYsYUEhv3/view?usp=sharing
>>>>>>> 201d604dc79f16d67a2de15c919c1e3d911456ed
